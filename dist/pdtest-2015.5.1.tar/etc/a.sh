#!/usr/bin/env bash 

#rets=`awk NF pd.conf  | sed -n 's/^\[\(.*\)\]$/\1/p'`
#echo $rets
#for ret in $rets
#do
# echo $ret 
#done
#

#rets=$(awk NF pdclient.conf | awk /\[getinfo\]/{while(getline)})
function A {
local var=$1
nrname="getinfo"
subcom="vg"
confname="pdclient.conf"


rets=$(awk NF $confname  | awk '/\['`echo $nrname`'\]/{while(getline)if($0!~/\[/) print;else exit;}' | sed '/^\s*#/d' | egrep "=" | egrep "${subcom}=")
ret=`echo $rets | tr " " "!"`
#echo $ret
eval $var="$ret"
}
A out_args
args=`echo $out_args | tr "!" " "`
for arg in $args
do
    echo $arg
done
